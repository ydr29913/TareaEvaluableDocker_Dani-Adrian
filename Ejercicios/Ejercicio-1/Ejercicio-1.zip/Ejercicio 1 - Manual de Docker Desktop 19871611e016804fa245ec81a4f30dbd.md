# Ejercicio 1 - Manual de Docker Desktop

> Realizado: Dani Gayol Rodríguez
> 

# **Introducción**

- **Panel Principal**
    
    El panel de principal de Docker Desktop es el siguiente:
    
    ![image.png](image.png)
    

- **Funciones de Docker Desktop**
    
    ### **Contenedores**
    
    - Permite gestionar el ciclo de vida de los contenedores (iniciar, detener, reiniciar).
    - Acceso a logs, terminal e inspección de contenedores.
    
    ### **Imágenes**
    
    - Gestión de imágenes locales y en Docker Hub.
    - Permite ejecutar contenedores desde imágenes y visualizar vulnerabilidades.
    
    ### **Volúmenes**
    
    - Lista y creación de volúmenes Docker.
    
    ### **Builds**
    
    - Historial y gestión de construcciones de imágenes.
    
    ### **Extensiones**
    
    - Añaden nuevas funcionalidades a Docker Desktop.
    
    ![image.png](image%201.png)
    

- **Otras funciones**
    - **Configuración y solución de problemas:** Ajustes y reinicio de Docker Desktop.
    - **Notificaciones y actualizaciones:** Avisos sobre nuevas versiones.
    - **Centro de aprendizaje:** Acceso a documentación.
    - **Dev Environments:** Creación de entornos de desarrollo en contenedores.
    - **Docker Scout:** Detección de vulnerabilidades en imágenes.
    
    ![image.png](image%202.png)
    

- **Panel de búsqueda**
    - Búsqueda de contenedores, imágenes, extensiones, volúmenes y documentación.
    - Acciones rápidas como iniciar/detener contenedores o extraer imágenes.
    
    ![image.png](image%203.png)
    

- **Menú Docker**
    - Acceso rápido a Dashboard, configuración, Docker Hub, Kubernetes y solución de problemas.
    - Cambio entre contenedores Windows/Linux (en Windows).
    - Opción para dar feedback y cerrar Docker Desktop.

# Gestión de Imágenes

- **Descarga de imágenes**
    - Permite buscar imágenes en “Docker Hub” y visualizar información como ID, etiquetas, fecha de creación, tamaño y documentación.
    
    - Acciones disponibles:
        - **Pull:** Descarga la imagen al registro local.
        - **Run:** Crea un contenedor desde la imagen.
        
        ![image.png](image%204.png)
        

- **Listado de imágenes**
    - **Pestaña Local:** Muestra imágenes descargadas con información sobre nombre, ID, etiqueta, estado, fecha de creación y tamaño.
        - **Acciones disponibles:**
            - **Run:** Ejecutar un contenedor.
            - **View packages and CVEs:** Inspeccionar archivos y vulnerabilidades.
            - **Pull:** Descargar versión actualizada.
            - **Push to Hub:** Subir la imagen a Docker Hub.
            - **Delete:** Eliminar imagen del registro local.
    
    - **Pestaña Hub:** Permite ver imágenes almacenadas en **Docker Hub** (requiere inicio de sesión) y acceder a:
        - **View en Hub:** Abrir la página de la imagen en Docker Hub.
        - **Pull:** Descargar imagen al registro local.
        
        ![image.png](image%205.png)
        

- **Inspección de imágenes**
    - Permite ver información detallada de una imagen:
        - **Image hierarchy:** Comandos usados para su creación (similar a “docker history”).
        - **Vulnerabilidades:** Lista de problemas de seguridad en los paquetes instalados.
        - **Paquetes:** Muestra los paquetes presentes en la imagen.
        
        ![image.png](image%206.png)
        

# Gestión de Contenedores

- **Ejecución de contenedores**
    - Se puede ejecutar un contenedor desde una imagen local usando **Run**.
    
    - Configuración disponible:
        - Nombre del contenedor.
        - Mapeo de puertos.
        - Almacenamiento (volúmenes o bind mounts).
        - Variables de entorno.
        
        ![image.png](image%207.png)
        

- **Listado de contenedores**
    - Muestra información como:
        - Recursos utilizados (CPU y RAM).
        - Nombre, ID e imagen de origen.
        - Estado (en ejecución, detenido, etc.).
        - Mapeo de puertos y tiempo de creación.
    
    - **Acciones disponibles:**
        - Iniciar, detener y eliminar contenedores.
        - **View details:** Información detallada.
        - **View packages and CVEs:** Inspección de vulnerabilidades.
        - **Copy docker run:** Copia el comando para recrear el contenedor.
        - **Open in terminal:** Acceso interactivo al contenedor.
        - **View files:** Ver archivos dentro del contenedor.
        - **Pause/Restart:** Pausar o reiniciar el contenedor.
        - **Open with browser:** Acceder a la aplicación desde el navegador.
        
        ![image.png](image%208.png)
        

- **Inspección de contenedores**
    - **Logs:** Registros del contenedor.
    - **Inspect:** Información detallada y personalizable.
    - **Bind mounts:** Directorios montados en el contenedor.
    - **Exec:** Acceso interactivo al contenedor.
    - **Files:** Listado y modificaciones de archivos.
    - **Stats:** Gráficas de uso de recursos (CPU, RAM, disco, red).
    
    ![image.png](image%209.png)
    

- **Docker Compose en Docker Desktop**
    - Visualización de escenarios creados con **Docker Compose**.
    - Permite **iniciar, detener y eliminar** escenarios y sus contenedores.
    - Muestra detalles y logs de los contenedores involucrados.
    
    ![image.png](image%2010.png)
    

# Gestión de Volúmenes

- **Listado de volúmenes**
    - Muestra la lista de volúmenes con información sobre:
        - Nombre del volumen.
        - Estado (en uso o disponible).
        - Tiempo desde su creación.
        - Tamaño.
    
    - Permite **eliminar volúmenes** que no estén en uso.
    
    - Al seleccionar un volumen, se puede ver:
        - Los archivos almacenados.
        - El contenedor que lo está utilizando.
        
        ![image.png](image%2011.png)
        

- **Creación de volúmenes**
    - Posibilidad de crear nuevos volúmenes asignándoles un nombre.
    
    ![image.png](image%2012.png)
    

# Gestión de Creación de Imágenes

- **Historial y construcción activa**
    - Permite inspeccionar el historial de construcciones realizadas.
    - Muestra la construcción en curso.
    - En la construcción activa, solo es posible acceder a los **logs**.
    
    Historial:
    
    ![image.png](image%2013.png)
    
    Logs:
    
    ![image.png](image%2014.png)
    

- **Inspección de construcciones finalizadas**
    - **Info:** Información general sobre la construcción.
        - **Source details:** Datos sobre el **Dockerfile** y su repositorio.
        - **Build timing:** Gráficos sobre tiempos de compilación, uso de CPU, caché y ejecución paralela.
        - **Dependencies:** Imágenes y recursos externos usados en la construcción.
    - **Configuration:** Parámetros de compilación como argumentos y etiquetas.
    - **Build results:** Resumen de los artefactos generados.
    - **Source:** Muestra el **Dockerfile** utilizado y señala errores si los hay.
    - **Logs:** Registra la ejecución de cada paso de la construcción.
    - **History:** Datos estadísticos y tendencias sobre compilaciones anteriores.
    
    ![image.png](image%2015.png)
    

# Extensiones

Las extensiones agregan nuevas funcionalidades a Docker Desktop. Se pueden buscar e instalar desde el repositorio de extensiones disponibles.

- **Ejemplos de extensiones útiles:**
    - **Disk Usage:** Visualiza y optimiza el almacenamiento Docker, permitiendo eliminar objetos no utilizados.
    
    ![image.png](image%2016.png)
    
    - **Logs Explorer:** Centraliza la visualización de logs de contenedores, con opciones de búsqueda y filtrado.
    
    ![image.png](image%2017.png)
    
    - **Resource Usage:** Monitorea en tiempo real el uso de recursos de los contenedores (CPU, RAM, red y disco).
    
    ![image.png](image%2018.png)
    
    - **Volumes Backup & Share:**
        - Exporta volúmenes a archivos comprimidos o imágenes.
        - Importa datos a un volumen nuevo.
        - Transfiere volúmenes vía **SSH** a otros hosts con Docker.
        - Clona, vacía o elimina volúmenes.
        
        ![image.png](image%2019.png)
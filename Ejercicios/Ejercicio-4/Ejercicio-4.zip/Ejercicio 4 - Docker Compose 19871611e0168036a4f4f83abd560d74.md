# Ejercicio 4 - Docker Compose

> Realizado: Dani Gayol Rodríguez
> 

## Crear archivo docker-compose.yaml

Crear el archivo “docker-compose.yaml”:

```bash
$ sudo nano docker-compose.yaml
```

![image.png](image.png)

Introducir esto en el fichero:

```yaml
version: '3.8'
services:
  htop:
    image: ubuntu:latest
    container_name: htop
    tty: true
    stdin_open: true
    command: bash -c "apt-get update && apt-get install -y htop && bash"

```

## Ejecutar el contenedor con docker-compose

```bash
$ docker compose up -d
```

![image.png](image%201.png)

## Acceder a la terminal

```bash
htop
```

![image.png](image%202.png)

## Funcionamiento de la Aplicación

“Htop” es una herramienta para monitorear los recursos del sistema en Linux. Muestra de manera visual el uso de la CPU, memoria, el estado de los procesos en ejecución, y otros recursos del sistema. A diferencia de “top”, “htop” permite una interacción más fácil con la interfaz gráfica, con opciones para buscar, ordenar y terminar procesos sin necesidad de recordar los comandos exactos.